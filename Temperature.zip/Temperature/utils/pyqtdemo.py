import cv2
import sys
import socket
import json
import time
import random
import os
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from threading import *
import time

from utils.algorithmThread import TemperatureThread



host = "117.78.1.201" #AIOT云平台tcp连接host地址
port = 8600           #AIOT云平台tcp连接port

def socket_client(host,port):
    ''''
    创建TCP连接
    '''
    handshare_data = {
            "t": 1,                                    #固定数据代表连接请求
            "device": "15689926008",                 #设备标识
            "key": "f015fadb62bd4341a2fb233ab9b02b9b", #传输密钥
            "ver": "v1.0"}                             #客户端代码版本号,可以是自己拟定的一组客户端代码版本号值
    try:
        tcp_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM) #创建socket
        tcp_client.connect((host,port))                                #建立tcp连接
        tcp_client.send(json.dumps(handshare_data).encode())           #发送云平台连接请求
        res_msg = tcp_client.recv(1024).decode()                       #接收云平台响应
    except Exception as e:
        print(e)
        return False
    return tcp_client                                                  #返回socket对象


def listen_server(socket_obj):
    '''
    监听TCP连接服务端消息
    :param socket_obj:
    :return:
    '''
    while True:
        try:
            res = socket_obj.recv(1024).decode() #接收服务端数据
            if not res:
                exit()
        except Exception as e:
            print(e)
            exit()


def tcp_ping(socket_obj):
    '''
    TCP连接心跳包
    :param socket_obj:
    :param obj:
    :return:
    '''
    while True:
        try:
            socket_obj.send("$#AT#".encode())   #发送心跳包数据
            time.sleep(30)
        except Exception as e:
            print(e)
            exit()


# 一大堆引用,乱七八糟,都要用到
# 需要继承QWidget,初始化窗体
class initform(QWidget):

    def __init__(self):
        super().__init__()

        return self.initUI()

    def initUI(self):
        self.tem_val = 0
        # 线程 体温获取线程
        self.temthread = TemperatureThread(self)
        self.temthread.tem_signal.connect(self.set_temp)
        self.temthread.start()

        # 设置窗口左上边距,宽度高度
        self.setGeometry(0, 0,1920,1080)
        # 设置窗体标题
        self.setWindowTitle("test")

        self.layout=QGridLayout(self)
        #设置lable文本内容
        self.lable = QLabel("iamlable", self)
        # self.lable.move(0,0)
        # label的对其方式,为左上对其
        self.lable.setAlignment(Qt.AlignTop)
        self.lable.setAlignment(Qt.AlignLeft)

        # 设置lable的大小
        self.lable.setGeometry(0, 0,1520, 1080)
        # self.lable.size(800,600)
        self.lable.setScaledContents(True)

        self.label_temp = QLabel(self)
        #self.lable3 = QLabel(self)
        self.label_temp.setGeometry(1520,0,400,540)
        self.label_temp.setText('当前温度：{:.1f}℃'.format(self.tem_val))
        self.label_temp.setFont(QFont("Roman times", 20, QFont.Bold))
        self.label_temp.setScaledContents(True)

        self.label_result = QLabel(self)
        # self.lable3 = QLabel(self)
        self.label_result.setGeometry(1520, 540, 400, 540)
        self.label_result.setText("温度异常!\n请注意核查!")
        self.label_result.setFont(QFont("Roman times", 20, QFont.Bold))
        self.label_result.setScaledContents(True)



        # label = QLabel(self)
        # self.tem_val = 37.3
        #label.setText('当前温度：{:.1f}℃'.format(self.tem_val))
        # label.setFont(QFont("Roman times", 20, QFont.Bold))
        # label.move(1520, 100)  # 按钮坐标位置,越高坐标越小左上角为（0，0）
        # label.hide()
        #
        # label2 = QLabel(self)
        # label2.setText("温度异常!\n请注意核查！")
        # label2.setFont(QFont("Roman times", 20, QFont.Bold))
        # label2.move(1520, 300)
        # label2.hide()
        # if self.tem_val > 2:
        #     label2.hide()

        self.show()

    def SetPic(self, img):
        # self.lable.setPixmap(QPixmap(imgPath))
        # 图片显示
        self.lable.setPixmap(QPixmap.fromImage(img))
        # print(QPixmap(imgPath))

    def set_temp(self):
        """
        温度显示
        :return:
        """

        if self.tem_val:
            self.label_temp.setText('当前温度：{:.1f}℃'.format(self.tem_val))
            self.send_temperature(tcp_client, self.tem_val)  # 发送一条体温数据



            if self.tem_val >= 37.3:
                self.label_result.show()
            else:
                self.label_result.hide()
        else:
            self.label_result.hide()
            self.label_temp.setText("当前温度：00℃")

    def send_temperature(self, tcp_client, num):
        '''

        :param tcp_client: socket对象
        :param num: 体温数据
        :return:
        '''
        if num > 37.3:
            data = {
                "t": 3,  # 固定数字,代表数据上报
                "datatype": 1,  # 数据上报格式类型
                "datas": {
                    "Temprature": num,  # 体温数据
                    "Temprature": num,  # 异常体温数据
                },
                "msgid": str(random.randint(100, 100000))  # 消息编号
            }
        else:
            data = {
                "t": 3,
                "datatype": 1,
                "datas": {
                    "Temprature": num,
                },
                "msgid": str(random.randint(100, 100000))
            }
        try:
            tcp_client.send(json.dumps(data).encode())  # 发送数据
        except Exception as e:
            print(e)

        # label3 = QLabel(self)
        # label4 = QLabel(self)
        # #self.tem_val = 37.3
        # label3.setText('当前温度：{:.1f}℃'.format(self.tem_val))
        # label3.setFont(QFont("Roman times",10, QFont.Bold))
        # label3.move(1520, 500)  # 按钮坐标位置,越高坐标越小左上角为（0，0）
        # label3.show()
        #
        # label4 = QLabel(self)
        # label4.setText("温度异常!\n请注意核查！")
        # label4.setFont(QFont("Roman times",10, QFont.Bold))
        # label4.move(1520, 600)
        # label4.hide()
        # if self.tem_val > 37.3:
        #     label4.show()
        # else:
        #     label3.setText('当前温度：{:.1f}℃'.format(self.tem_val))




# 上面的这个来控制进程结束
def showcamre():
    # 参数0代表系统第一个摄像头,第二就用1 以此类推
    detector = cv2.CascadeClassifier(r'F:\Py_experiment\msk\haarcascade_frontalface_default.xml')
    mask_detector = cv2.CascadeClassifier(r'F:\Py_experiment\msk\cascade.xml')
    #detector = cv2.CascadeClassifier(r'./haarcascade_frontalface_default.xml')
    #mask_detector = cv2.CascadeClassifier(r'./cascade.xml')
    cap = cv2.VideoCapture(0)


    # 设置显示分辨率和FPS ,不设置的话会非常卡
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 800)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 600)
    cap.set(cv2.CAP_PROP_FPS, 100)
    while cap.isOpened():
        if thstop:
            return
        ret, frame = cap.read()

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = detector.detectMultiScale(gray, 1.1, 3)



        if ret == False:
            continue
        # 水平翻转,很有必要
        #frame = cv2.flip(frame, 1)
        # opencv 默认图像格式是rgb qimage要使用BRG,这里进行格式转换,不用这个的话,图像就变色了,困扰了半天,翻了一堆资料
        frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)

        for (x, y, w, h) in faces:
            # 参数分别为 图片、左上角坐标，右下角坐标，颜色，厚度
            face = frame[y:y + h, x:x + w]  # 裁剪坐标为[y0:y1, x0:x1]
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
            # 在左半部分最上方打印文字
            cv2.putText(frame, 'No MASK', (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

            mask_face = mask_detector.detectMultiScale(gray, 1.1, 5)

            for (x2, y2, w2, h2) in mask_face:
                cv2.rectangle(frame, (x2, y2), (x2 + w2, y2 + h2), (255, 0, 255), 2)
                # cv2.putText(img, 'MASK', (x2, y2), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
        # mat-->qimage
        a = QImage(frame.data, frame.shape[1], frame.shape[0], QImage.Format_RGB888)
        ex.SetPic(a)

if __name__ == '__main__':
    thstop = False
    app = QApplication(sys.argv)
    ex = initform()
    # 全屏显示
    # ex.showFullScreen()
    # 使用线程,否则程序卡死

    th = Thread(target=showcamre)
    th.start()

    tcp_client = socket_client(host, port)  # 创建tcp　sockt 对象
    t1 = Thread(target=listen_server, args=(tcp_client,))  # 监听服务端发送数据
    t1.start()
    t2 = Thread(target=tcp_ping, args=(tcp_client,))  # 创建与云平台保持心跳的线程
    t2.start()

    app.exec_()
    # 退出的时候,结束进程,否则,关不掉进程
    thstop = True
