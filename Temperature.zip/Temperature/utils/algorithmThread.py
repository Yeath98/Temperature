# -*- coding: utf-8 -*-
import time
import os
import sys
import socket
import json
import time
import random
from threading import Thread
from PyQt5 import QtCore
from PyQt5.QtCore import QThread
from smbus2 import SMBus


class TemperatureThread(QThread):
    tem_signal = QtCore.pyqtSignal(int)
    def __init__(self, mw):
        self.mw = mw
        self.working = True
        QThread.__init__(self)
        self.AMG88xx_I2CADDR = 0x69  # I2C协议地址
        self.AMG88xx_PCTL = 0x00  # 操作模式的寄存器地址
        self.AMG88xx_RST = 0x01  # 软件重置的寄存器地址
        self.AMG88xx_FPSC = 0x02  # 刷新率fps的寄存器地址
        self.AMG88xx_INTC = 0x03  # 中断寄存器地址
        self.AMG88xx_STAT = 0x04  #
        self.AMG88xx_SCLR = 0x05  # I2C时钟地址
        # 0x06 reserved
        self.AMG88xx_AVE = 0x07
        self.AMG88xx_INTHL = 0x08
        self.AMG88xx_INTHH = 0x09
        self.AMG88xx_INTLL = 0x0A
        self.AMG88xx_INTLH = 0x0B
        self.AMG88xx_IHYSL = 0x0C
        self.AMG88xx_IHYSH = 0x0D
        self.AMG88xx_TTHL = 0x0E
        self.AMG88xx_TTHH = 0x0F
        self.AMG88xx_INT_OFFSET = 0x010  # 中断偏移量
        self.AMG88xx_PIXEL_OFFSET = 0x80  # 像素偏移量

        # 操作模式的相关值
        self.AMG88xx_NORMAL_MODE = 0x00  # 正常模式值
        self.AMG88xx_SLEEP_MODE = 0x01  # 睡眠模式值
        self.AMG88xx_STAND_BY_60 = 0x20
        self.AMG88xx_STAND_BY_10 = 0x21

        # 软件重置的相关值
        self.AMG88xx_FLAG_RESET = 0x30  # 标志重置的值
        self.AMG88xx_INITIAL_RESET = 0x3F  # 中断重置的值

        # 帧速率的相关值
        self.AMG88xx_FPS_10 = 0x00  # 每秒10帧
        self.AMG88xx_FPS_1 = 0x01  # 每秒1帧

        # 中断使能相关值
        self.AMG88xx_INT_DISABLED = 0x00  # 禁用中断
        self.AMG88xx_INT_ENABLED = 0x01  # 启用中断

        # 中断模式
        self.AMG88xx_DIFFERENCE = 0x00  # 差异值
        self.AMG88xx_ABSOLUTE_VALUE = 0x01  # 绝对值

        self.AMG88xx_PIXEL_ARRAY_SIZE = 64  # 像素点数组的大小，8*8的数组值
        self.AMG88xx_PIXEL_TEMP_CONVERSION = .25  # 像素与温度转换
        self.AMG88xx_THERMISTOR_CONVERSION = .0625  # 热敏电阻转换

    def __del__(self):
        self.wait()

    def run(self):
        try:
            self.bus = SMBus(1)  # 实例化I2C总线对象
            addr = self.AMG88xx_I2CADDR  # 把I2C地址赋给addr

            # 写入byte数据，进入正常模式，第一个参数为I2C地址，第二个为要写入的寄存器地址，第三个为写入寄存器地址的值
            self.bus.write_byte_data(addr, self.AMG88xx_PCTL, self.AMG88xx_NORMAL_MODE)
            # 写入byte数据，进行软件重置
            self.bus.write_byte_data(addr, self.AMG88xx_RST, self.AMG88xx_INITIAL_RESET)
            # 写入byte数据，禁用中断，默认是禁用的
            self.bus.write_byte_data(addr, self.AMG88xx_INTC, self.AMG88xx_INT_DISABLED)
            # 写入byte数据，设置 10 FPS的刷新率
            self.bus.write_byte_data(addr, self.AMG88xx_FPSC, self.AMG88xx_FPS_10)
            time.sleep(0.1)  # 延时0.1秒
            while True:
                # 每隔1秒循环获取温度值，温度值为8*8的数组
                tem_list = []
                for i in range(0, self.AMG88xx_PIXEL_ARRAY_SIZE):
                    try:
                        # 读取像素点的值
                        raw = self.bus.read_word_data(addr, self.AMG88xx_PIXEL_OFFSET + (i << 1))
                        # 根据像素点与温度的转换关系，进行温度值转换
                        converted = self.twoCompl12(raw) * self.AMG88xx_PIXEL_TEMP_CONVERSION
                        # 将温度值放入列表中
                        tem_list.append(converted)
                    except Exception as e:
                        print('TemperatureThread:', e)
                print('temper: ', tem_list)  # 打印出温度数组值
                if tem_list:  # 如果温度值存在，则以8*8排列，取数组最中间的四个值，取平均值作为温度值，这个可以自己定义，去哪些值最为温度
                    tem_val = ((tem_list[27] + tem_list[28] + tem_list[35] + tem_list[36]) / 4)+10
                    #print((tem_list[27] + tem_list[28] + tem_list[35] + tem_list[36]) / 1)

                    self.mw.tem_val = tem_val
                    print('result: ', tem_val)  # 打印最终的温度值
                    self.tem_signal.emit(0)
                else:
                    self.mw.tem_val = ''
                    self.tem_signal.emit(0)
                #time.sleep(1)
        except Exception as e:

            print('temperature is system error ' + str(e))

        if not self.working:
            self.bus.close()

    def twoCompl12(self, val):
        """
        像素值转换
        :param val:
        :return:
        """
        if 0x7FF & val == val:
            return float(val)
        else:
            return float(val - 4096)

    def stop(self):
        if self.working:
            print('TemperatureThread quit!')
            self.working = False