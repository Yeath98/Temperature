# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Temperature.ui'
#
# Created by: PyQt5 UI code generator 5.13.1
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from threading import *
import sys



class Ui_Form(object):

    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(920, 1080)
        self.label_temp = QtWidgets.QLabel(Form)
        self.label_temp.setGeometry(QtCore.QRect(300, 300, 1280, 271))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.label_temp.setFont(font)
        self.label_temp.setAlignment(QtCore.Qt.AlignCenter)
        self.label_temp.setObjectName("label_temp")
        self.label_result = QtWidgets.QLabel(Form)
        self.label_result.setGeometry(QtCore.QRect(510, 600, 861, 101))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.label_result.setFont(font)
        self.label_result.setStyleSheet("background-color: rgb(255, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.label_result.setAlignment(QtCore.Qt.AlignCenter)
        self.label_result.setObjectName("label_result")
        self.label_background = QtWidgets.QLabel(Form)
        self.label_background.setGeometry(QtCore.QRect(0, 0, 1920, 100))
        self.label_background.setStyleSheet("color: rgb(76, 229, 229);\n"
"font: 75 25pt \"微软雅黑\";\n"
"background-color: rgb(237, 248, 255);\n"
"")
        self.label_background.setAlignment(QtCore.Qt.AlignCenter)
        self.label_background.setObjectName("label_background")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.label_temp.setText(_translate("Form", "当前温度：38℃"))
        self.label_result.setText(_translate("Form", "温度异常，请注意核查！"))
        self.label_background.setText(_translate("Form", "体温检测"))

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    widget = QtWidgets.QWidget()
    ui = Ui_Form()
    ui.setupUi(widget)
    widget.show()
    sys.exit(app.exec_())
