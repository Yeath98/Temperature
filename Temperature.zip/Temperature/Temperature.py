# -*- coding: utf-8 -*-
import os
import sys

from PyQt5.QtWidgets import QApplication, QMainWindow

from UI.Temperature import Ui_Form
from utils.algorithmThread import TemperatureThread


class Temper(QMainWindow, Ui_Form):
    """
    温度模块
    """
    def __init__(self):
        super(Temper, self).__init__()
        self.setupUi(self)
        self.label_temp.setText("当前温度：00℃")
        self.label_result.hide()
        self.tem_val = 0
        # 线程 体温获取线程
        self.temthread = TemperatureThread(self)
        self.temthread.tem_signal.connect(self.set_temp)
        self.temthread.start()

    def set_temp(self):
        """
        温度显示
        :return:
        """
        if self.tem_val:
            self.label_temp.setText('当前温度：{:.1f}℃'.format(self.tem_val))
            if self.tem_val >= 37.3:
                self.label_result.show()
            else:
                self.label_result.hide()
        else:
            self.label_result.hide()
            self.label_temp.setText("当前温度：00℃")


if __name__ == '__main__':
    BASE_PATH = os.path.dirname(os.path.abspath(__file__))  # 项目根目录路径
    app = QApplication(sys.argv)
    temp_page = Temper()  # 温度界面调用
    temp_page.show()  # 显示温度界面
    sys.exit(app.exec_())