#coding=utf-8
import socket
import os
import threading
import time

kouzhao_flag=0

def ThreadExist(pname):
    tl = threading.enumerate()
    for tid in tl:
        print(tid)
        if tid.getName() == pname:
            #print(pname,'exist!\n')
            return True
    #print(pname,'not exist!\n')
    return False
        
def dishaomusic():
    cmusic='/home/pi/face/voice/dishao.mp3'
    os.system('mplayer %s' % cmusic)
    time.sleep(3)

def gaoshaomusic():
    cmusic='/home/pi/face/voice/gaoshao.mp3'
    os.system('mplayer %s' % cmusic)
    time.sleep(3)

def kouzhaomusic():
    cmusic='/home/pi/face/voice/kouzhao.mp3'
    os.system('mplayer %s' % cmusic)
    time.sleep(3)

def tongshimusic():
    cmusic='/home/pi/face/voice/tongshi.mp3'
    os.system('mplayer %s' % cmusic)
    time.sleep(3)
        
def zhengchangmusic():
    cmusic='/home/pi/face/voice/zhengchang.mp3'
    os.system('mplayer %s' % cmusic)
    time.sleep(3)

def runall():
    global kouzhao_flag
  
    server = socket.socket()  # 默认是AF_INET、SOCK_STREAM
    server.bind(("127.0.0.1",6868))   # 将主机号与端口绑定到套接字
    server.listen(1)   # 设置并启动TCP监听器
    while True:
        conn,addr = server.accept()   # 被动接受TCP连接，一直等待连接到达
        data = conn.recv(1024)   # 接收TCP消息，并制定最大长度
        print(data)
        if(data==b'1'):    #未带口罩
            #if(kouzhao_flag>2 and (not ThreadExist("kouzhao"))):
            kouzhao_flag = kouzhao_flag + 1
            if(not ThreadExist("kouzhao")):
                if(kouzhao_flag>2):
                    #t_kouzhao=threading.Thread(name="kouzhao", target=kouzhaomusic)
                    #t_kouzhao.start()
                    kouzhao_flag=0                
        elif(data==b'2'):    #低烧
            if(not ThreadExist("dishao")):
                t_dishao=threading.Thread(name="dishao", target=dishaomusic)
                t_dishao.start()
        elif(data==b'3'):    #高烧
            if(not ThreadExist("gaoshao")):
                t_gaoshao=threading.Thread(name="gaoshao", target=gaoshaomusic)
                t_gaoshao.start()
        elif(data==b'00'):   #体温正常
            if(not ThreadExist("zhengchang")):
                t_zhengchang=threading.Thread(name="zhengchang", target=zhengchangmusic)
                t_zhengchang.start()
        
        #war()
    server.close()

if __name__=="__main__":
    runall()




    










