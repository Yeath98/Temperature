import tkinter as tk  # 使用Tkinter前需要先导入
import threading
from PIL import Image, ImageTk
import serial
import time
import binascii
import heapq
import numpy as np
import os
import socket
import sys


TEMPGAP = 30  #温度变化阈值，用于判断移动目标,3度
TEMPADJUST = 2   #环境温度偏差校准，需现场测量


s1=[0xF0,0x4F,0x01,0xEF,0xEE]
#s1=[0xEE,0xE1,0x01,0x55,0xFF,0xFC,0xFD,0xFF]
ser = serial.Serial("/dev/ttyUSB0",115200)                    #打开、设置串口参数
if(ser.isOpen()==False):                              #串口是否打开，如果是返回True
    print("串口打开失败！")
    ser.open()                                        #如果报错，重新打开串口

count=0
dis = 10    #人脸距离，以米m为单位。初始值为无限远
disptemp = 0 #显示的温度，测量过程不断取最大值
backTemp = [0]*1024 #用于存放背景温度数据
backTempNum = 0   #背景温度数据帧数
countStatus = 0   #测温状态：0-无人；1-有人进入，但距离远；2-距离在测温范围内

def chongqi():
    python = sys.executable   
    os.execl(python, python, * sys.argv)

#计算温度，blist为当前温度数据列表，backTemp为背景温度数据表
def getTemp(blist):

    global backTemp
    global backTempNum
    global countStatus

    blistVar = [] #扣除背景温度为数据
    for k in range(1023):
        blistVar.append(0)
    
    #系统初始化时，首先计算背景温度,这时认为没人进入
    if(backTempNum <21):
        backTempNum = backTempNum + 1

        if(backTempNum ==1):
            p = 0
            for p in range(1023):
                backTemp[p] = blist[p]
        elif((backTempNum >=10)  and (backTempNum < 20)):   #取10-19共10个点的平均值
            p = 0
            for p in range(1023):
                backTemp[p] = backTemp[p]*0.7 + blist[p]*0.3
        '''
        elif(backTempNum == 20):
            p = 0
            for p in range(1023):
                backTemp[p] = backTemp[p] / 10 #取平均值
        '''
        top10 = heapq.nlargest(10, backTemp)
        avgcount = np.mean(top10)  # 取平均温度
        temp = round(((avgcount - 2731) / 10), 1)
        #temp = round( backTemp[512],1)
        return temp   #返回中间点数据作为测量的温度

    #扣除背景数据，判断是否有人进入
    p = 0
    countVar = 0  #有突变的数据点个数
    for p in range(1023):
        if(abs(blist[p] - backTemp[p]) > TEMPGAP):
            countVar = countVar + 1
            blistVar[p]=blist[p]
        #else:
         #   blistVar[p] = blist[p] - backTemp[p] #背景温度数据扣除

    #根据突变点个数，计算距离
    if(countVar > 800 ):  #距离过近
        dis = 0
    else:
        dis = (820-countVar)/800 - 0.1

    if(dis>0.80):  #小于5个点的突变
        countStatus = 0
    elif(dis > 0.65):
        countStatus = 1  #1-有人进入，但距离远
    else:
        countStatus = 2  #2-距离在测温范围内
   
    #后续的背景温度数据进行滚动叠加即可
    if(countStatus == 0):  #无人进入，则可以计算背景数据
        p = 0
        for p in range(1023):
            backTemp[p] = backTemp[p]*0.7 + blist[p]*0.3
        

    #计算温度
    xishu = 0.6839 * dis * dis * dis - 0.7337 * dis * dis + 0.2992 * dis + 0.9995   #距离系数
    
    if(countStatus == 0):  #无人，用背景温度计算
        top10 = heapq.nlargest(10, backTemp)  # 取列表中最大的10个数
    elif(countStatus == 1):  #有人靠近，用当前温度计算
        top10 = heapq.nlargest(10, blist)  # 取列表中最大的10个数
    elif(countStatus == 2):  #距离够近，用扣除背景的温度计算
        top10 = heapq.nlargest(10, blistVar)  # 取列表中最大的10个数

    if(countStatus == 0):  #无人，背景温度取总平均值
        avgcount = np.mean(backTemp)  # 取平均温度
    else：
        avgcount = np.mean(top10)  # 取平均温度
    temp = round(((avgcount - 2731) / 10), 1)
    if(dis == 0):
        wendu=round((temp*xishu+0.5),1)
    else:
        wendu=round((temp*xishu+TEMPADJUST),1)
    
    
    print("突变点数：",countVar,"距离：",dis,"温度：",wendu,"校准系数：",xishu)
   
    return wendu                                 #函数测到的温度

def openser(ser,s1):
    global count
    global dis
    global gap


    '''p = 0
    blist = {}
    for p in range(1023):
        blist[p] = 3031 - backTempNum
    time.sleep(1)  # 延时1s'''

    result = ser.write(s1)  # 向模块发送数据
    time.sleep(0.3)  # 延时1s
    n = ser.inWaiting()  # 获取缓冲区内的数据字节个数
    if(n==0):             #如果恢复数据个数为0，将串口关闭再重新开启
        print("串口数据回复出错！")
        ser.close()
        time.sleep(5)
        chongqi()

    # print("模块回复总字节数:",n)
    s2 = binascii.b2a_hex(ser.read(n))  # 读取返回的数据，16进制
    data=[]
    data = s2.decode("utf-8")

    # 截取有效字符串
    sumtp = ''
    l = len(data)
    ln = l - 16
    sumtpnew = data[8:ln]  # 因为第0个和第1个数据不是温度数据，从第2个开始

    # 将字符串分为四个一组的链表
    lnew = len(sumtpnew) - 1
    step = 4
    b_list = [sumtpnew[i:i + step] for i in range(0, len(sumtpnew), step)]
    m = len(b_list)

    # 十六进制转十进制
    j = 0
    while j < m:
        b_list[j] = int(b_list[j], 16)
        j += 1
   
    return getTemp(b_list)    


window = tk.Tk()
window.title('                                                                                   体温检测报警系统')
window.geometry('720x460+910+0')
window.pack_propagate()
frame_left = tk.Frame(window)
frame_right = tk.Frame(window, bg='greenyellow')
frame_left.pack(side='left', expand=1, fill='both')
frame_right.pack(side='right', expand=0, fill='both')

label = tk.Label(frame_right, fg="black", bg="greenyellow",font =("宋体", 34),width=12, height=1)
#t.pack(expand=1, fill='both')
label.pack(expand=1, fill='x')
t = tk.Label(frame_right,text='初始值',font =("宋体", 34), width=12, height=1)
t.pack(expand=1, fill='both')
btimage=tk.PhotoImage(file="/home/pi/face/bt.gif")
#bt1=tk.Button(frame_right, text='QUST',font =("宋体", 48),command=insertText).pack(expand=1, fill='both')
bt1=tk.Button(frame_right,image=btimage,width=13, height=10).pack(expand=1, fill='both')


def counter_label(label):  #温度变化
    def mycount():
        global disptemp
        client = socket.socket()  # 默认是AF_INET、SOCK_STREAM
        client.connect(("127.0.0.1", 6868))
        wen = openser(ser,s1)
        #label.config(text=("温度",wen))
        if(countStatus == 0):  #无人
            disptemp = wen
            print("无人")
            #s=(b"22")
            #client.sendall(s)
            #client.close()
            t.config(text=("无人"),bg="cornsilk")
        elif(countStatus == 1): #有人进入，但距离太远
            disptemp = wen
            t.config(text=("请靠近测温"),bg="green")
        elif(countStatus == 2): #可以测量
            disptemp = wen
            if ((disptemp>=32.0)and(disptemp <= 37.3)):  # 按温度值来判断是否发烧
                s=(b"00")
                client.sendall(s)
                client.close()
                t.config(text=("体温正常"),bg="green")
            elif ((disptemp > 37.3) and (disptemp <= 38.2)):
                print("低烧")
                t.config(text=("低烧"),bg="yellow")
                s=(b"2")
                client.sendall(s)
                client.close()
            elif (disptemp > 38.2):
                print("高烧")
                t.config(text=("高烧"),bg="red")
                s=(b"3")
                client.sendall(s)
                client.close()
        else:  #>0.5m
            disptemp = wen
        label.config(text=("温度",disptemp))
        label.after(300, mycount)
    mycount()
    
counter_label(label)
window.mainloop()



