cd /home/pi/face1
#sudo python3 server_test.py &
sudo python3 cewen_ui.py &
sudo python3 shipin_ui_0.5.py &
