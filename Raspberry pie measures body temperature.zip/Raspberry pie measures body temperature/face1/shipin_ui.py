import tkinter as tk  # 使用Tkinter前需要先导入
import threading
from mask_detection import inference
import cv2
from PIL import Image, ImageTk
import time
import binascii
import heapq
import numpy as np
#import cwvoice as mu

window = tk.Tk()
window.title('人脸口罩检测系统')
window.geometry('550x460+800+1')
window.pack_propagate()
frame_left = tk.Frame(window)
frame_right = tk.Frame(window, bg='yellow')
frame_left.pack(side='left', expand=1, fill='both')
frame_right.pack(side='right', expand=1, fill='both')

counter = -1
index = 0

def insertText():  # 采集按钮对应回调函数
    global index
    t.delete(0.0, tk.END)
    t.insert('insert', str(index))
    index = index + 1
    print('insert')

panel = tk.Label(frame_right)  # initialize image panel
#t = tk.Text(frame_right, width=16, height=2)
#label = tk.Label(frame_right, fg="black", bg="yellow",font =("宋体", 48),width=3, height=1)
panel.pack(expand=1, fill="both")
#t.pack(expand=1, fill='both')
#label.pack(expand=1, fill='both')
#tk.Button(frame_right, text='商标区域', command=insertText).pack(expand=1, fill='both')



cap = cv2.VideoCapture(0)

def video_cam():
    status, img_raw = cap.read()
        
    if status:
        #cv2.waitKey(1)
        img_raw = cv2.cvtColor(img_raw, cv2.COLOR_BGR2RGB)
        if (status):
            img_raw = inference(img_raw,
                      conf_thresh=0.5,
                      iou_thresh=0.5,
                      target_shape=(260, 260),
                      draw_result=True)
                      
            #img = img_raw[:, :, ::-1]
            current_image = Image.fromarray(img_raw)  # 将图像转换成Image对象
            imgtk = ImageTk.PhotoImage(image=current_image)
            panel.imgtk = imgtk
            panel.config(image=imgtk)
            #cv2.imshow('image', img_raw[:, :, ::-1])
            window.after(1, video_cam)

video_cam()
window.mainloop()

# 当一切都完成后，关闭摄像头并释放所占资源
camera.release()
cv2.destroyAllWindows()

